﻿Public Class Class1
    'PROPIEDADES'
    Public nombre As String
    Public raza As String
    Public altura As String

    'CONSTRUCTOR'
    Public Sub New()

    End Sub

    Public Sub New(nombre As String, raza As String, altura As String)
        Me.nombre = nombre
        Me.raza = raza
        Me.altura = altura
    End Sub
    'METODO'
    Public Sub ladrar()

    End Sub


    Public Sub dormir()

    End Sub

    Public Function comer(Carne As String) As String
        Return Me.nombre & "mide " & Me.altura & "y comerá " & Carne
    End Function
End Class
