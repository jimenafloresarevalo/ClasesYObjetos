﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim perrito As Class1 = New Class1()
        perrito.nombre = "Steve "
        perrito.raza = "Golden Retriver "
        perrito.altura = "0.70cm "
        TextBox1.Text = perrito.comer("Concentrado de Pollo")

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim perrito2 As Class1 = New Class1()
        perrito2.nombre = "Fachero "
        perrito2.raza = "Chihuahua "
        perrito2.altura = "0.25cm "
        TextBox1.Text = perrito2.comer("pollo azado ")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim perrito3 As Class1 = New Class1()
        perrito3.nombre = "Max "
        perrito3.raza = "French Poodle "
        perrito3.altura = "0.30cm "
        TextBox1.Text = perrito3.comer("Pan ")
    End Sub
End Class
